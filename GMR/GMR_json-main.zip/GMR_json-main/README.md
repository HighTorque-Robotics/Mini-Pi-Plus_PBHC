# GMR
## 1. 下载原项目
https://github.com/YanjieZe/GMR

## 2. 添加文件到相应目录下
1. 添加json文件到GMR/general_motion_retargeting/ik_configs/文件夹下
2. 添加机器人的pi_plus_24dof_250826文件到/GMR/assets/文件夹下

## 3. 修改params.py文件
ROBOT_XML_DICT 添加xml路径
```
    "pi_football": ASSET_ROOT / "pi_plus_24dof_250826" /"xml"/ "pi_22dof_0826.xml",
```

IK_CONFIG_DICT 添加本项目提供的json文件路径
```
        "pi_football": IK_CONFIG_ROOT / "bvh_to_pi_football.json",
```

![params.jpg](params.jpg)

## 4. 添加--robot
在有parser.add_argument("--robot",的地方都加上"pi_football"，例如：
```
 parser.add_argument("--robot", type=str, choices=["unitree_g1", "booster_t1", "stanford_toddy","hightorque_hi","pi","pi_waist","pi_football"],
                        default="unitree_g1"
                        )
```


## 说明
1. pi+使用的是无腰部的pi_plus_24dof_250826.zip的模型，提供的xml是没有手部的。
2. 原项目中有hi的smpl示例和xml文件，本项目提供的是hi重定向lafan的json。仍需微调相应参数

# 数据说明
smplx重定向amass，cmu的数据都是支持的，要使用XG类型数据集


# 可能的现象
1. 双脚过于靠拢，可以调脚部的offset

2. 穿模或者飘空中可以设置 offset_to_ground=True
